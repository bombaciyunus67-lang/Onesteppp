// BISS-C encoders
#pragma once

#include "../EncoderBase.h"

#ifdef HAS_BISS_C

  // designed according protocol description found in as38-H39e-b-an100.pdf

  // similar broadcom devices have range of 10MHz to 80 KHz
  #ifndef BISSC_CLOCK_RATE_KHZ
    #define BISSC_CLOCK_RATE_KHZ 4000
  #endif

  // default to single turn mode
  #ifndef BISSC_SINGLE_TURN
    #define BISSC_SINGLE_TURN ON
  #endif

  // flag error if encoder is outside absolute range
  // this applies to forced single turn mode and encoders that are inherently single turn
  #ifndef BISSC_SINGLE_TURN_STRICT
    #define BISSC_SINGLE_TURN_STRICT ON
  #endif

  // default sync phase
  #ifndef BISSC_SYNC_PHASE
    #define BISSC_SYNC_PHASE 20
  #endif

  // default ack phase
  #ifndef BISSC_ACK_PHASE
    #define BISSC_ACK_PHASE 20
  #endif

  // sample during the low phase after LOW_MA
  #ifndef BISSC_SAMPLE_IN_LOW_PHASE
    #define BISSC_SAMPLE_IN_LOW_PHASE ON
  #endif

  // sample during the high phase after HIGH_MA
  #ifndef BISSC_SAMPLE_IN_HIGH_PHASE
    #define BISSC_SAMPLE_IN_HIGH_PHASE OFF
  #endif

  // sample point within the selected half-clock phase, in quarter-cycle steps (2 is mid-cycle and default)
  #ifndef BISSC_TSAMPLE_QUARTERS
    #define BISSC_TSAMPLE_QUARTERS 2
  #endif

  #if BISSC_SAMPLE_IN_LOW_PHASE == BISSC_SAMPLE_IN_HIGH_PHASE
    #error "Configuration (Config.h): Set exactly one of BISSC_SAMPLE_IN_LOW_PHASE or BISSC_SAMPLE_IN_HIGH_PHASE to ON"
  #endif
  #if BISSC_TSAMPLE_QUARTERS < 1
    #error "Configuration (Config.h): BISSC_TSAMPLE_QUARTERS must be >= 1"
  #endif
  #if BISSC_TSAMPLE_QUARTERS > 3
    #error "Configuration (Config.h): BISSC_TSAMPLE_QUARTERS must be between 1 and 3"
  #endif

  // resolution adjustment use 2, 4, or 8 (example:)
  //#define BISSC_RESOLUTION_DIVISOR 4

  // allow for inverting the signal state to fix incorrect wiring if needed
  #ifndef HIGH_SLO
  #define HIGH_SLO HIGH
  #endif
  #ifndef LOW_SLO
  #define LOW_SLO LOW
  #endif
  #ifndef HIGH_MA
  #define HIGH_MA HIGH
  #endif
  #ifndef LOW_MA
  #define LOW_MA LOW
  #endif

  class Bissc : public Encoder {
    public:
      // get device ready for use
      bool init();

      bool isAbsolute() const override { return true; }

      // set encoder origin
      void setOrigin(int32_t counts);

      // read encoder position
      int32_t read();

      // write encoder position
      void write(int32_t position);

    protected:
      // read encoder count with 1 second error recovery
      // returns encoder count or INT32_MAX on error
      int32_t getCountWithErrorRecovery(bool immediate = false);

      // read encoder count
      bool getCount(uint32_t &count);

      // low level bitbang read encoder count
      IRAM_ATTR void getCountBitBang(uint32_t &count);

      // the custom crc routine
      virtual uint8_t crc6(uint64_t data) = 0;

      bool foundAck = false;
      bool foundStart = false;
      bool foundCds = false;

      uint8_t  nErr = 1;
      uint8_t  nWrn = 1;
      uint8_t  frameCrc = 0;

      uint32_t turns = 0;

      int32_t lastCountSingleTurn = 0;
      int32_t countTurns = 0;
      bool firstCall = true;

      // this design allows for 8 to 31 bit encoders
      char encoderName[16] = {0};
      uint8_t encoderBits = 0;
      uint32_t encoderCounts = 0;
      int32_t encoderHalfCounts = 0;
      uint32_t encoderCountsPerTurn = 0;
      uint32_t encoderHalfCountsPerTurn = 0;
      uint8_t encoderMultiTurnBits = 0;
      uint32_t encoderMultiTurnMask = 0;
      bool encoderWrnInvert = true;
      bool encoderErrInvert = true;

      uint32_t good = 0;
      uint32_t bad = 0;
      uint16_t nvAddress = 0;

      // bit delay in nanoseconds
      const uint32_t rate = 500000/BISSC_CLOCK_RATE_KHZ;
      const uint32_t tSample = (rate*BISSC_TSAMPLE_QUARTERS)/4;

      int16_t maPin;
      int16_t sloPin;

      uint32_t lastValidTime = 0;
      int32_t lastValidCount = 0;
  };

#endif
