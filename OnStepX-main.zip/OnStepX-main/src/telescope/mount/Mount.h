//--------------------------------------------------------------------------------------------------
// telescope mount control
#pragma once

#include "../../Common.h"

#ifdef MOUNT_PRESENT

#include "../../lib/axis/Axis.h"
#include "../../libApp/commands/ProcessCmds.h"
#include "coordinates/Transform.h"
#include "home/Home.h"

enum RateCompensation: uint8_t {RC_NONE, RC_REFRACTION, RC_REFRACTION_DUAL, RC_MODEL, RC_MODEL_DUAL};

#if TRACK_COMPENSATION_DEFAULT == OFF
  #define RC_DEFAULT RC_NONE
#elif TRACK_COMPENSATION_DEFAULT == REFRACTION
  #define RC_DEFAULT RC_REFRACTION
#elif TRACK_COMPENSATION_DEFAULT == REFRACTION_DUAL
  #define RC_DEFAULT RC_REFRACTION_DUAL
#elif TRACK_COMPENSATION_DEFAULT == MODEL
  #define RC_DEFAULT RC_FULL
#elif TRACK_COMPENSATION_DEFAULT == MODEL_DUAL
  #define RC_DEFAULT RC_MODEL_DUAL
#endif

enum TrackingState: uint8_t    {TS_NONE, TS_SIDEREAL};

#pragma pack(1)
#define MountSettingsSize 9

typedef struct Backlash {
  float axis1;
  float axis2;
} Backlash;

typedef struct MountSettings {
  RateCompensation rc;
  Backlash backlash;
  uint8_t mountType;
} MountSettings;

typedef struct MountPositionMemory {
  float a1;
  float a2;
  uint8_t mountType:4;
  uint8_t seq:2;
  uint8_t untrusted:1;
  uint8_t reserved:1;
} MountPositionMemory;

#pragma pack()

extern Axis axis1;
extern Axis axis2;

class Mount {
  public:
    void init();
    void begin();

    bool command(char *reply, char *command, char *parameter, bool *suppressFrame, bool *numericReply, CommandError *commandError);

    // get current equatorial position (Native coordinate system)
    Coordinate getPosition(CoordReturn coordReturn = CR_MOUNT_EQU);

    // get current equatorial position (Mount coordinate system)
    Coordinate getMountPosition(CoordReturn coordReturn = CR_MOUNT_EQU);

    // returns true if either of the mount motor drivers report a fault
    bool motorFault();

    // true when either motor has an absolute encoder or SWS supplied trusted absolute positions
    bool hasAbsoluteEncoders() const;

    // returns true if the mount is at the home (startup) position
    inline bool isHome() {
      return abs(axis1.getInstrumentCoordinate() - home.getPosition(CR_MOUNT).a1) <= arcsecToRad(AXIS1_HOME_TOLERANCE) &&
             abs(axis2.getInstrumentCoordinate() - home.getPosition(CR_MOUNT).a2) <= arcsecToRad(AXIS2_HOME_TOLERANCE);
    }

    // returns true if the mount is slewing (doing a goto or guide > 2X)
    inline bool isSlewing() { return axis1.isSlewing() || axis2.isSlewing(); }

    // one time initialization of tracking
    void autostart();
    void autostartPostponed();

    // enables or disables tracking, enabling tracking powers on the motors if necessary
    void tracking(bool state);

    // returns true if the mount is tracking
    inline bool isTracking() { return trackingState == TS_SIDEREAL; }

    // enables or disables power to the mount motors
    void enable(bool state);

    // returns true if the mount motors are powered on
    inline bool isEnabled() {
      #if MOUNT_BRAKE == ON
        if (!brakeReleased || brakeFaultLatched) return false;
      #endif
      return axis1.isEnabled() && axis2.isEnabled();
    }

    // true if syncing only from OnStep to the Encoders
    bool syncFromOnStepToEncoders = false;

    void captureNominalIndexPositions();
    long getNominalIndexPositionSteps(uint8_t axisNumber) const;

    #if MOUNT_COORDS_MEMORY == ON
      void saveCoordinateMemory(bool trusted);
    #endif

    // updates the tracking rates, etc. as appropriate for the mount state
    // called once a second by poll() but available here for immediate action
    void update();

    void poll();

    // all in sidereal units 1x = 15 arc-seconds/sidereal second
    float trackingRate = hzToSidereal(TRACKING_RATE_DEFAULT_HZ);
    float trackingRateAxis1 = 0.0F;
    float trackingRateAxis2 = 0.0F;
    float trackingRateOffsetRA = 0.0F;
    float trackingRateOffsetDec = 0.0F;

    MountSettings settings = {RC_DEFAULT, { 0, 0 }, MOUNT_SUBTYPE};

  private:
    #if MOUNT_BRAKE == ON
      void initBrake();
      void beginBrake();
      void engageBrake();
      void releaseBrake();
      void latchBrakeFault();
      bool brakeMonitoring = false;
      bool brakeReleased = false;
      bool brakeFaultLatched = false;
    #endif

    bool swsAbsoluteEncodersPresent = false;
    // calculate tracking and transformed pulse-guide rates in sidereal units
    void calculateTrackingRates();

    // alternate tracking rate calculation method
    float ztr(float a);

    // update where we are pointing *now*
    void updatePosition(CoordReturn coordReturn);

    // current position in Mount coordinates (Observed Place with no corrections except index offset)
    // coordinates are either Horizon (a, z) or Equatorial (h, d) depending on the mountType
    // also includes Mount normalized axis coordinates (a1, a2) where a2 is an instrument coordinate in tangent arm mode
    Coordinate current;

    TrackingState trackingState = TS_NONE;

    uint32_t nvKey;

    #if MOUNT_COORDS_MEMORY == ON
      uint32_t nvKeyLastA, nvKeyLastB;
      MountPositionMemory lastPosition;
    #endif

    long nominalIndexAxis1Steps = 0;
    long nominalIndexAxis2Steps = 0;
};

extern Motor& motor1;
extern Axis axis1;

extern Motor& motor2;
extern Axis axis2;

extern Mount mount;

#endif
